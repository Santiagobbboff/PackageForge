package dev.packageforge;

import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.os.Bundle;
import com.android.apksig.ApkVerifier;
import java.io.*;

/** Framework-only instrumentation: exercises the actual on-device Keystore and service. */
public class SmokeInstrumentation extends Instrumentation {
    @Override public void onCreate(Bundle args) { super.onCreate(args); start(); }
    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            Context app = getTargetContext();
            app.getPackageManager().getApplicationInfo("dev.packageforge.fixture",0);
            MainActivity activity = (MainActivity) startActivitySync(new Intent(app,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            waitForIdleSync();
            Intent job = new Intent(app,ForgeService.class).putExtra("installed","dev.packageforge.fixture")
                .putExtra("target","com.antutu.ABenchMark").putExtra("label","Cloned Fixture").putExtra("patch",true);
            app.startForegroundService(job);
            long deadline = System.currentTimeMillis()+120000; boolean started=false;
            while (System.currentTimeMillis()<deadline) {
                if(ForgeService.running)started=true;
                if(started&&!ForgeService.running)break;
                if(!started&&ForgeService.result!=null)break;
                Thread.sleep(100);
            }
            if (ForgeService.running || ForgeService.result==null || ForgeService.error!=null) throw new AssertionError("Service failed: "+ForgeService.error+" / "+ForgeService.message);
            File apk=ForgeService.result;
            if(!new ApkVerifier.Builder(apk).setMinCheckedPlatformVersion(26).build().verify().isVerified())throw new AssertionError("Invalid APK signature");
            if(!app.getPackageManager().getPackageArchiveInfo(apk.getPath(),0).packageName.equals("com.antutu.ABenchMark"))throw new AssertionError("Wrong package");
            File copy=new File(app.getExternalFilesDir(null),"smoke-clone.apk");
            try(InputStream in=new FileInputStream(apk);OutputStream out=new FileOutputStream(copy)){dev.packageforge.engine.CloneEngine.copy(in,out,dev.packageforge.engine.CloneEngine.MAX_BYTES);}
            Thread.sleep(1000); waitForIdleSync();
            Bitmap screen=getUiAutomation().takeScreenshot();
            try(OutputStream out=new FileOutputStream(new File(app.getExternalFilesDir(null),"smoke-screen.png"))){screen.compress(Bitmap.CompressFormat.PNG,100,out);} screen.recycle();
            result.putString("stream","PASS: installed APK extraction, package rewrite, resource parsing, DEX rewrite, Android Keystore signing, v1/v2 verification, service completion, UI launch.\nClone: "+copy.getPath()+"\n");
            finish(Activity.RESULT_OK,result);
        } catch(Throwable e) { result.putString("stream","FAIL: "+android.util.Log.getStackTraceString(e));finish(Activity.RESULT_CANCELED,result); }
    }
}
