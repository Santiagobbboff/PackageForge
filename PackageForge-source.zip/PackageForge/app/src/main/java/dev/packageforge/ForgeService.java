package dev.packageforge;

import android.app.*;
import android.content.*;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.*;
import dev.packageforge.engine.CloneEngine;
import java.io.*;
import java.util.*;

public class ForgeService extends Service {
    static final String CHANNEL = "forge-jobs";
    static final int NOTIFICATION = 41;
    static volatile boolean running;
    static volatile String message = "Ready when you are";
    static volatile int progress;
    static volatile String error;
    static volatile File result;
    private Thread worker;
    private volatile boolean cancelled;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(CHANNEL, "APK creation", NotificationManager.IMPORTANCE_LOW));
    }
    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_launcher).setContentTitle("Package Forge")
            .setContentText(message).setContentIntent(pending).setOngoing(true).setProgress(100, progress, false).build();
    }
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent == null) { stopSelf(id); return START_NOT_STICKY; }
        if ("cancel".equals(intent.getAction())) { cancel(); return START_NOT_STICKY; }
        if (running) return START_NOT_STICKY;
        running = true; cancelled = false; error = null; result = null; progress = 0; message = "Preparing workspace";
        getSharedPreferences("forge", 0).edit().putBoolean("activeJob", true).apply();
        startForeground(NOTIFICATION, notification());
        wakeLock = ((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PackageForge:build");
        wakeLock.acquire(2 * 60 * 60 * 1000L);
        worker = new Thread(() -> execute(intent), "apk-forge"); worker.start();
        return START_NOT_STICKY;
    }
    private void report(int percent, String text) throws IOException {
        CloneEngine.checkCancelled(); if (cancelled) throw new InterruptedIOException("Cancelled");
        progress = percent; message = text;
        getSystemService(NotificationManager.class).notify(NOTIFICATION, notification());
    }
    private void execute(Intent intent) {
        File work = new File(getCacheDir(), "active-job"); File signed = null;
        try {
            clear(work); if (!work.mkdirs()) throw new IOException("Cannot create workspace.");
            List<File> inputs = new ArrayList<>();
            String installed = intent.getStringExtra("installed");
            if (installed != null) {
                ApplicationInfo info = getPackageManager().getApplicationInfo(installed, 0);
                List<String> paths = new ArrayList<>(); paths.add(info.sourceDir);
                if (info.splitSourceDirs != null) paths.addAll(Arrays.asList(info.splitSourceDirs));
                for (int i = 0; i < paths.size(); i++) {
                    report(8, "Extracting installed APK " + (i + 1) + " of " + paths.size());
                    File file = new File(work, "installed-" + i + ".apk");
                    try (InputStream in = new FileInputStream(paths.get(i)); OutputStream out = new FileOutputStream(file)) { CloneEngine.copy(in, out, CloneEngine.MAX_BYTES); }
                    inputs.add(file);
                }
            } else {
                String[] uris = intent.getStringArrayExtra("uris");
                if (uris == null || uris.length == 0 || uris.length > CloneEngine.MAX_APKS) throw new IOException("Select an APK or bundle first (at most 512 files).");
                for (int i = 0; i < uris.length; i++) {
                    report(6, "Copying selected file " + (i + 1) + " of " + uris.length);
                    File file = new File(work, "input-" + i + ".zip");
                    try (InputStream in = getContentResolver().openInputStream(Uri.parse(uris[i])); OutputStream out = new FileOutputStream(file)) {
                        if (in == null) throw new IOException("The document provider could not open this file.");
                        CloneEngine.copy(in, out, CloneEngine.MAX_BYTES);
                    }
                    inputs.addAll(CloneEngine.unpack(file, new File(work, "parts-" + i), this::report));
                }
            }
            if (inputs.size() > CloneEngine.MAX_APKS) throw new IOException("Too many splits.");
            long bytes = 0; for (File f : inputs) bytes += f.length();
            if (bytes > CloneEngine.MAX_BYTES) throw new IOException("Combined APKs exceed 4 GiB.");
            if (getCacheDir().getUsableSpace() < bytes * 3 + 64L * 1024 * 1024) throw new IOException("Not enough free storage. Keep at least three times the input size free after importing.");
            File unsigned = new File(work, "unsigned.apk"); String target = intent.getStringExtra("target");
            CloneEngine.build(inputs, unsigned, work, target, intent.getStringExtra("label"), intent.getBooleanExtra("patch", true), this::report);
            report(84, "Signing with your device's private key");
            File exports = new File(getFilesDir(), "exports"); if (!exports.isDirectory() && !exports.mkdirs()) throw new IOException("Cannot create output folder.");
            signed = new File(exports, target + "-" + System.currentTimeMillis() + ".apk");
            LocalSigner.sign(unsigned, signed);
            report(98, "Checking finished APK");
            android.content.pm.PackageInfo parsed = getPackageManager().getPackageArchiveInfo(signed.getPath(), 0);
            if (parsed == null || !target.equals(parsed.packageName)) throw new IOException("Android could not read the resulting package.");
            getSharedPreferences("forge", 0).edit().putString("lastOutput", signed.getName()).putString("lastError", null).commit();
            result = signed; progress = 100; message = "Your APK is ready";
        } catch (Exception | OutOfMemoryError e) {
            if (signed != null) signed.delete();
            error = cancelled || e instanceof InterruptedIOException ? "Cancelled. You can start again." : (e instanceof OutOfMemoryError ? "This app is too large for available memory. Try a smaller APK or disable package-string patching." : e.getMessage());
            if (error == null) error = e.getClass().getSimpleName();
            message = "Could not finish";
            getSharedPreferences("forge", 0).edit().putString("lastError", error).commit();
        } finally {
            clear(work);
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            getSharedPreferences("forge", 0).edit().putBoolean("activeJob", false).commit();
            running = false; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
        }
    }
    static void clear(File file) {
        if (file.isDirectory()) { File[] children = file.listFiles(); if (children != null) for (File child : children) clear(child); }
        file.delete();
    }
    private void cancel() { cancelled = true; message = "Cancelling after the current step…"; if (worker != null) worker.interrupt(); }
    @Override public void onTimeout(int startId, int fgsType) { cancel(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); }
    @Override public void onDestroy() { if (running && worker != null && worker.isAlive()) cancel(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
