package dev.packageforge;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import com.android.apksig.ApkSigner;
import com.android.apksig.ApkVerifier;
import java.io.File;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import javax.security.auth.x500.X500Principal;

final class LocalSigner {
    private static final String ALIAS = "package-forge-clones-v1";
    static void sign(File input, File output) throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias(ALIAS)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore");
            Calendar end = Calendar.getInstance(); end.add(Calendar.YEAR, 30);
            generator.initialize(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                .setKeySize(2048).setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                .setCertificateSubject(new X500Principal("CN=Package Forge Local Clones"))
                .setCertificateSerialNumber(new BigInteger(120, new SecureRandom()))
                .setCertificateNotBefore(new Date(1577836800000L)).setCertificateNotAfter(end.getTime())
                .setUserAuthenticationRequired(false).build());
            generator.generateKeyPair();
        }
        PrivateKey key = (PrivateKey) store.getKey(ALIAS, null);
        X509Certificate certificate = (X509Certificate) store.getCertificate(ALIAS);
        ApkSigner.SignerConfig config = new ApkSigner.SignerConfig.Builder("PackageForge", key, Collections.singletonList(certificate)).build();
        new ApkSigner.Builder(Collections.singletonList(config)).setInputApk(input).setOutputApk(output)
            .setMinSdkVersion(26).setV1SigningEnabled(true).setV2SigningEnabled(true)
            .setV3SigningEnabled(false).setV4SigningEnabled(false).setCreatedBy("Package Forge").build().sign();
        ApkVerifier.Result result = new ApkVerifier.Builder(output).setMinCheckedPlatformVersion(26).build().verify();
        if (!result.isVerified()) throw new GeneralSecurityException("Output signature verification failed: " + result.getErrors());
    }
}
