package dev.packageforge;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.*;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import dev.packageforge.engine.CloneEngine;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(16,23,21), CARD = Color.rgb(26,36,32), INK = Color.rgb(235,244,237), MUTED = Color.rgb(157,178,166), MINT = Color.rgb(168,240,198), LINE = Color.rgb(49,69,58), AMBER = Color.rgb(244,198,126);
    private static final int OPEN = 100, SAVE = 101, INSTALL_PERMISSION = 102;
    private static final String[] PRESET_NAMES = {"Custom package", "AnTuTu Benchmark", "Geekbench 6", "Geekbench 5"};
    private static final String[] PRESET_PACKAGES = {"", "com.antutu.ABenchMark", "com.primatelabs.geekbench6", "com.primatelabs.geekbench5"};
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<View> controls = new ArrayList<>();
    private SharedPreferences prefs;
    private LinearLayout root, outputPanel;
    private TextView sourceTitle, sourceDetail, status, progressLabel, resultDetail, collision;
    private EditText packageField, labelField;
    private CheckBox patch;
    private Button build, cancel;
    private ProgressBar bar;
    private String installed, selectedTitle = "No app selected", selectedDetail = "Choose an installed app or open a file.";
    private ArrayList<String> uris = new ArrayList<>();
    private File output;
    private boolean wasRunning, editingPreset;
    private final Runnable ticker = new Runnable() { @Override public void run() { refreshJob(); handler.postDelayed(this, 500); } };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved); prefs = getSharedPreferences("forge", 0);
        if (!ForgeService.running && prefs.getBoolean("activeJob", false)) prefs.edit().putBoolean("activeJob", false).putString("lastError", "The previous job was interrupted. Select your source and try again.").apply();
        if (saved != null) {
            installed = saved.getString("installed"); uris = saved.getStringArrayList("uris"); if (uris == null) uris = new ArrayList<>();
            selectedTitle = saved.getString("sourceTitle", selectedTitle); selectedDetail = saved.getString("sourceDetail", selectedDetail);
        } else {
            installed = prefs.getString("sourceInstalled", null);
            selectedTitle = prefs.getString("sourceTitle", selectedTitle); selectedDetail = prefs.getString("sourceDetail", selectedDetail);
            try { org.json.JSONArray a = new org.json.JSONArray(prefs.getString("sourceUris", "[]")); for (int i = 0; i < a.length(); i++) uris.add(a.getString(i)); } catch (Exception ignored) {}
        }
        createUi();
        packageField.setText(saved == null ? prefs.getString("target", PRESET_PACKAGES[1]) : saved.getString("target"));
        labelField.setText(saved == null ? prefs.getString("label", "") : saved.getString("label"));
        patch.setChecked(saved == null ? prefs.getBoolean("patch", true) : saved.getBoolean("patch", true));
        restoreOutput(); refreshJob();
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int color, int stroke) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(20)); if (stroke != 0) d.setStroke(dp(1), stroke); return d; }
    private TextView text(String value, float size, int color) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setLineSpacing(dp(3), 1); return t; }
    private void bold(TextView t) { t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout.LayoutParams match() { return new LinearLayout.LayoutParams(-1, -2); }
    private void gap(LinearLayout parent, int height) { View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1, dp(height))); }
    private LinearLayout card(String step, String title) {
        LinearLayout l = column(); l.setPadding(dp(20),dp(20),dp(20),dp(20)); l.setBackground(shape(CARD, LINE));
        TextView eyebrow = text(step, 11, MINT); eyebrow.setLetterSpacing(.14f); bold(eyebrow); l.addView(eyebrow); gap(l,8);
        TextView heading = text(title, 21, INK); bold(heading); l.addView(heading); gap(l,16);
        root.addView(l, match()); gap(root,16); return l;
    }
    private Button button(String value, boolean primary, View.OnClickListener click) {
        Button b = new Button(this); b.setText(value); b.setAllCaps(false); b.setTextSize(14); bold(b); b.setMinHeight(dp(50)); b.setMinimumHeight(dp(50));
        b.setPadding(dp(12),dp(8),dp(12),dp(8)); b.setTextColor(primary ? BG : INK); b.setBackground(shape(primary ? MINT : LINE, 0)); b.setOnClickListener(click); return b;
    }
    private void row(LinearLayout parent, View left, View right) {
        LinearLayout row = new LinearLayout(this); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); p.setMarginEnd(dp(8)); row.addView(left,p);
        row.addView(right,new LinearLayout.LayoutParams(0,-2,1)); parent.addView(row,match());
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(15); e.setTextColor(INK); e.setHintTextColor(MUTED); e.setHint(hint);
        e.setPadding(dp(14),dp(14),dp(14),dp(14)); e.setBackground(shape(BG,LINE)); e.setSelectAllOnFocus(false); controls.add(e); return e;
    }
    private void createUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        root = column(); root.setPadding(dp(20),dp(18),dp(20),dp(30)); scroll.addView(root);
        scroll.setOnApplyWindowInsetsListener((v,insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom()); return insets.consumeSystemWindowInsets();
        });
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView wordmark = text("▣  PACKAGE FORGE",12,MINT); wordmark.setLetterSpacing(.12f); bold(wordmark); header.addView(wordmark,new LinearLayout.LayoutParams(0,-2,1));
        Button help = button("About",false,v -> about()); header.addView(help,new LinearLayout.LayoutParams(dp(76),dp(42))); root.addView(header); gap(root,24);
        TextView title = text("A new identity.\nOne APK.",36,INK); bold(title); title.setLineSpacing(0,1); root.addView(title); gap(root,10);
        root.addView(text("Extract, merge and rename — all on your phone.",15,MUTED)); gap(root,14);
        TextView badge = text("●  OFFLINE     /     NO ROOT REQUIRED",10,MINT); badge.setLetterSpacing(.08f); root.addView(badge); gap(root,26);

        LinearLayout source = card("01  /  SOURCE", "Choose your app");
        Button apps = button("Installed apps",true,v -> pickInstalled()); Button files = button("Open file",false,v -> openFiles()); controls.add(apps); controls.add(files); row(source,apps,files); gap(source,16);
        sourceTitle = text(selectedTitle,16,INK); bold(sourceTitle); source.addView(sourceTitle); gap(source,4);
        sourceDetail = text(selectedDetail,12,MUTED); sourceDetail.setTextIsSelectable(true); source.addView(sourceDetail); gap(source,10);
        source.addView(text("APK · APKM · XAPK · APKS\nYou can also select a base APK and its splits together.",11,MUTED));

        LinearLayout identity = card("02  /  IDENTITY", "Make it yours");
        identity.addView(text("PACKAGE PRESET",10,MUTED)); gap(identity,4);
        Spinner presets = new Spinner(this); ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,PRESET_NAMES); presets.setAdapter(adapter); controls.add(presets); identity.addView(presets,match()); gap(identity,12);
        identity.addView(text("Package name",12,MUTED)); gap(identity,6); packageField = field("com.example.emulator");
        packageField.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        identity.addView(packageField,match());
        collision = text("",11,AMBER); gap(identity,6); identity.addView(collision); gap(identity,12);
        identity.addView(text("App name (optional)",12,MUTED)); gap(identity,6); labelField = field("Keep the original name"); labelField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(80)}); identity.addView(labelField,match()); gap(identity,12);
        patch = new CheckBox(this); patch.setText("Patch package strings in app code"); patch.setTextColor(INK); patch.setTextSize(13); patch.setButtonTintList(android.content.res.ColorStateList.valueOf(MINT)); controls.add(patch); identity.addView(patch);
        identity.addView(text("Updates package literals, provider addresses and custom permissions. Turn off if the cloned app behaves unexpectedly.",11,MUTED));
        presets.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int position, long id) { if (position > 0) { editingPreset = true; packageField.setText(PRESET_PACKAGES[position]); editingPreset = false; } }
            public void onNothingSelected(AdapterView<?> p) {}
        });
        packageField.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence s,int start,int count,int after) {} public void onTextChanged(CharSequence s,int start,int before,int count) { checkCollision(); if (!editingPreset) presets.setSelection(0); } public void afterTextChanged(Editable e) {} });

        LinearLayout process = card("03  /  EXPORT", "Forge your APK");
        process.addView(text("The result is signed with a key unique to this installation. Apps with signature checks or hardcoded native package names may not work. Performance changes depend on your firmware.",12,MUTED)); gap(process,16);
        build = button("Create APK  →",true,v -> startBuild()); process.addView(build,match()); gap(process,16);
        status = text("Ready when you are",14,INK); bold(status); process.addView(status); gap(process,8);
        bar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); bar.setProgressTintList(android.content.res.ColorStateList.valueOf(MINT)); process.addView(bar,match());
        progressLabel = text("",11,MUTED); process.addView(progressLabel); gap(process,8);
        cancel = button("Cancel",false,v -> { Intent i = new Intent(this,ForgeService.class); i.setAction("cancel"); startService(i); }); cancel.setVisibility(View.GONE); process.addView(cancel,match());
        outputPanel = column(); gap(outputPanel,16); resultDetail = text("",12,MINT); resultDetail.setTextIsSelectable(true); outputPanel.addView(resultDetail); gap(outputPanel,12);
        row(outputPanel,button("Save APK",true,v -> saveOutput()),button("Share",false,v -> shareOutput())); gap(outputPanel,8);
        outputPanel.addView(button("Install APK",false,v -> installOutput()),match()); outputPanel.setVisibility(View.GONE); process.addView(outputPanel);
        TextView footer = text("Your original app stays installed. App data is not copied.\nLarge apps need extra free space during processing.",11,MUTED); footer.setGravity(Gravity.CENTER); root.addView(footer); gap(root,12);
        root.addView(button("Clear exported APKs",false,v -> clearExports()),match());
        setContentView(scroll);
    }
    private void about() {
        new AlertDialog.Builder(this).setTitle("Package Forge 1.0")
            .setMessage("Choose an installed app or an APK / split archive, pick a package name, and create a standalone signed APK. Android 8.0 or later.\n\nInstalled-app exports contain only the splits installed on this device. Multi-device APKS archives, source AABs, OBB data and encrypted archives are not supported.\n\nClones start with fresh app data. Google sign-in, billing, licensing, signature checks and native code may stop working. Renaming cannot guarantee higher clocks.\n\nIf a benchmark already uses the target package, Android may reject installation. Choose another preset or remove that conflicting app yourself.\n\nThe signing key stays in Android Keystore. Clearing app data or uninstalling Package Forge loses it, so later clones may need reinstalling. Save your exported APK before clearing it here.\n\nNo internet permission, uploads or analytics.\n\nAPK merging and resource editing: REAndroid ARSCLib (Apache 2.0). Signing: Android apksig (Apache 2.0). Full source and license notices are included with the project.")
            .setPositiveButton("Got it",null).show();
    }
    private void openFiles() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,OPEN);
    }
    private void pickInstalled() {
        LinearLayout box = column(); box.setPadding(dp(20),0,dp(20),dp(8)); EditText search = field("Search apps or package names"); box.addView(search,match());
        CheckBox system = new CheckBox(this); system.setText("Include system apps"); box.addView(system);
        TextView loading = text("Loading installed apps…",13,MUTED); box.addView(loading);
        ListView list = new ListView(this); box.addView(list,new LinearLayout.LayoutParams(-1,dp(360)));
        List<AppRow> all = new ArrayList<>(), visible = new ArrayList<>();
        ArrayAdapter<AppRow> adapter = new ArrayAdapter<AppRow>(this,android.R.layout.simple_list_item_2,android.R.id.text1,visible) {
            @Override public View getView(int position,View convert,android.view.ViewGroup parent) {
                View v = super.getView(position,convert,parent); AppRow app = getItem(position);
                TextView a = v.findViewById(android.R.id.text1), b = v.findViewById(android.R.id.text2); a.setText(app.name); a.setTextSize(15); b.setText(app.info.packageName + (app.splits > 0 ? " · " + app.splits + " splits" : "")); b.setTextSize(11); return v;
            }
        }; list.setAdapter(adapter);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Installed apps").setView(box).setNegativeButton("Cancel",null).create();
        Runnable filter = () -> {
            String q = search.getText().toString().toLowerCase(Locale.ROOT); visible.clear();
            for (AppRow app : all) if ((system.isChecked() || !app.system) && (app.name.toLowerCase(Locale.ROOT).contains(q) || app.info.packageName.toLowerCase(Locale.ROOT).contains(q))) visible.add(app);
            adapter.notifyDataSetChanged(); loading.setText(visible.size() + " apps");
        };
        search.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence s,int a,int c,int d) {} public void onTextChanged(CharSequence s,int a,int b,int c) { filter.run(); } public void afterTextChanged(Editable e) {} });
        system.setOnCheckedChangeListener((b,c) -> filter.run());
        list.setOnItemClickListener((p,v,position,id) -> {
            AppRow app = visible.get(position); installed = app.info.packageName; uris.clear(); selectedTitle = app.name;
            selectedDetail = installed + "\n" + (app.splits == 0 ? "Single APK" : "Base APK + " + app.splits + " splits; merged automatically") + " · " + formatBytes(app.bytes);
            sourceTitle.setText(selectedTitle); sourceDetail.setText(selectedDetail); saveState(); dialog.dismiss();
        });
        dialog.show();
        io.execute(() -> {
            List<AppRow> rows = new ArrayList<>();
            try { for (ApplicationInfo info : getPackageManager().getInstalledApplications(0)) if (!info.packageName.equals(getPackageName()) && info.sourceDir != null && new File(info.sourceDir).isFile()) rows.add(new AppRow(info));
                rows.sort((a,b) -> a.name.compareToIgnoreCase(b.name));
                runOnUiThread(() -> { if (!dialog.isShowing()) return; all.addAll(rows); filter.run(); });
            } catch (Exception e) { runOnUiThread(() -> loading.setText("Could not list apps: " + e.getMessage())); }
        });
    }
    private class AppRow {
        final ApplicationInfo info; final String name; final int splits; final boolean system; final long bytes;
        AppRow(ApplicationInfo value) { info=value; name=getPackageManager().getApplicationLabel(info).toString(); splits=info.splitSourceDirs==null?0:info.splitSourceDirs.length; system=(info.flags & ApplicationInfo.FLAG_SYSTEM)!=0;
            long size = new File(info.sourceDir).length(); if (info.splitSourceDirs != null) for (String path : info.splitSourceDirs) size += new File(path).length(); bytes = size; }
    }
    private void checkCollision() {
        String target = packageField.getText().toString().trim();
        if (!CloneEngine.validPackage(target)) { collision.setText("Use at least two dot-separated names, starting with letters."); return; }
        try { getPackageManager().getPackageInfo(target,0); collision.setText("This package is already installed. Android may reject the cloned APK if its signature differs."); }
        catch (PackageManager.NameNotFoundException e) { collision.setText(""); }
    }
    private void startBuild() {
        if (ForgeService.running) return;
        String target = packageField.getText().toString().trim();
        if (!CloneEngine.validPackage(target)) { packageField.setError("Enter a valid package name"); packageField.requestFocus(); return; }
        if (installed == null && uris.isEmpty()) { toast("Choose an installed app or APK first."); return; }
        if (target.equals(installed)) { packageField.setError("Choose a different package from the original"); return; }
        if (target.equals(getPackageName())) { packageField.setError("Choose a different package from Package Forge"); return; }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 103);
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(packageField.getWindowToken(),0);
        saveState(); output = null; prefs.edit().remove("lastOutput").remove("lastError").apply();
        Intent i = new Intent(this,ForgeService.class); i.putExtra("installed",installed); i.putExtra("uris",uris.toArray(new String[0])); i.putExtra("target",target); i.putExtra("label",labelField.getText().toString().trim()); i.putExtra("patch",patch.isChecked());
        try { startForegroundService(i); status.setText("Starting…"); }
        catch (Exception e) { toast("Could not start: " + e.getMessage()); }
    }
    private void refreshJob() {
        boolean running = ForgeService.running;
        for (View v : controls) v.setEnabled(!running); build.setEnabled(!running); build.setAlpha(running?.5f:1f);
        cancel.setVisibility(running ? View.VISIBLE : View.GONE); bar.setVisibility(running ? View.VISIBLE : View.GONE);
        if (running) { status.setText(ForgeService.message); status.setTextColor(INK); bar.setProgress(ForgeService.progress); progressLabel.setText(ForgeService.progress + "% · You can leave this screen while it works."); outputPanel.setVisibility(View.GONE); }
        else {
            if (wasRunning) restoreOutput();
            String error = prefs.getString("lastError",null);
            if (error != null) { status.setText(error); status.setTextColor(AMBER); }
            else { status.setText(output != null ? "Your APK is ready" : "Ready when you are"); status.setTextColor(INK); }
            progressLabel.setText("");
            outputPanel.setVisibility(output != null && output.isFile() ? View.VISIBLE : View.GONE);
            if (output != null) resultDetail.setText(output.getName()+"\n"+formatBytes(output.length())+" · Signature verified");
        }
        wasRunning = running;
    }
    private void restoreOutput() {
        String name = prefs.getString("lastOutput",null); output = name == null ? null : new File(new File(getFilesDir(),"exports"),name);
        if (output != null && !output.isFile()) { output=null; prefs.edit().remove("lastOutput").apply(); }
    }
    private Uri outputUri() { return new Uri.Builder().scheme("content").authority("dev.packageforge.exports").appendPath(output.getName()).build(); }
    private void saveOutput() {
        if (output == null) return; Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/vnd.android.package-archive"); i.putExtra(Intent.EXTRA_TITLE,output.getName()); startActivityForResult(i,SAVE);
    }
    private void shareOutput() {
        if (output == null) return; Uri uri = outputUri(); Intent i = new Intent(Intent.ACTION_SEND); i.setType("application/vnd.android.package-archive"); i.putExtra(Intent.EXTRA_STREAM,uri); i.setClipData(ClipData.newRawUri("APK",uri)); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(i,"Share APK")); } catch (ActivityNotFoundException e) { toast("No app is available to share this file."); }
    }
    private void installOutput() {
        if (output == null) return;
        if (!getPackageManager().canRequestPackageInstalls()) { Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())); try { startActivityForResult(i,INSTALL_PERMISSION); } catch (ActivityNotFoundException e) { toast("Allow installs from Package Forge in Android Settings, then tap Install APK."); } return; }
        Uri uri = outputUri(); Intent i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(uri,"application/vnd.android.package-archive"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); i.setClipData(ClipData.newRawUri("APK",uri));
        try { startActivity(i); } catch (ActivityNotFoundException e) { toast("No APK installer found. Save the APK and open it from Files."); }
    }
    private void clearExports() {
        if (ForgeService.running) { toast("Wait for the current job to finish."); return; }
        new AlertDialog.Builder(this).setTitle("Clear exported APKs?").setMessage("Deletes APK copies stored inside Package Forge. Files you saved elsewhere and installed apps are kept.")
            .setNegativeButton("Keep",null).setPositiveButton("Clear",(d,w) -> {
                ForgeService.clear(new File(getFilesDir(),"exports")); output=null; ForgeService.result=null; prefs.edit().remove("lastOutput").remove("lastError").apply(); refreshJob();
            }).show();
    }
    @Override protected void onActivityResult(int request,int code,Intent data) {
        super.onActivityResult(request,code,data);
        if (request == INSTALL_PERMISSION) { if (getPackageManager().canRequestPackageInstalls()) installOutput(); return; }
        if (code != RESULT_OK || data == null) return;
        if (request == OPEN) {
            uris.clear(); if (data.getClipData()!=null) for (int i=0;i<data.getClipData().getItemCount();i++) uris.add(data.getClipData().getItemAt(i).getUri().toString()); else if (data.getData()!=null) uris.add(data.getData().toString());
            if (uris.isEmpty()) return;
            for (String value : uris) try { getContentResolver().takePersistableUriPermission(Uri.parse(value),Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (SecurityException ignored) {}
            installed=null; selectedTitle=uris.size()==1?displayName(Uri.parse(uris.get(0))):uris.size()+" selected files";
            selectedDetail=uris.size()==1?"File selected · APK or split archive":"Include the base APK and every required split from the same app version.";
            sourceTitle.setText(selectedTitle); sourceDetail.setText(selectedDetail); saveState();
        } else if (request == SAVE && output != null && data.getData()!=null) {
            File file=output; Uri destination=data.getData(); toast("Saving APK…");
            io.execute(() -> { try (InputStream in=new FileInputStream(file); OutputStream out=getContentResolver().openOutputStream(destination,"wt")) {
                if (out==null) throw new IOException("Cannot open destination"); CloneEngine.copy(in,out,CloneEngine.MAX_BYTES); runOnUiThread(() -> toast("APK saved."));
            } catch (Exception e) { runOnUiThread(() -> toast("Save failed: "+e.getMessage())); } });
        }
    }
    private String displayName(Uri uri) { try (Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) { if(c!=null&&c.moveToFirst()) return c.getString(0); } catch(Exception ignored) {} return "Selected APK"; }
    private String formatBytes(long bytes) { return String.format(Locale.US,"%.1f MB",bytes/1048576.0); }
    private void toast(String text) { Toast.makeText(this,text,Toast.LENGTH_LONG).show(); }
    private void saveState() { if(prefs==null||packageField==null)return; prefs.edit().putString("target",packageField.getText().toString()).putString("label",labelField.getText().toString()).putBoolean("patch",patch.isChecked()).putString("sourceInstalled",installed).putString("sourceTitle",selectedTitle).putString("sourceDetail",selectedDetail).putString("sourceUris",new org.json.JSONArray(uris).toString()).apply(); }
    @Override protected void onSaveInstanceState(Bundle b) { super.onSaveInstanceState(b); b.putString("installed",installed);b.putStringArrayList("uris",uris);b.putString("sourceTitle",selectedTitle);b.putString("sourceDetail",selectedDetail);b.putString("target",packageField.getText().toString());b.putString("label",labelField.getText().toString());b.putBoolean("patch",patch.isChecked()); }
    @Override protected void onResume() { super.onResume(); restoreOutput(); handler.post(ticker); }
    @Override protected void onPause() { saveState(); handler.removeCallbacks(ticker); super.onPause(); }
    @Override protected void onDestroy() { io.shutdown(); super.onDestroy(); }
}
