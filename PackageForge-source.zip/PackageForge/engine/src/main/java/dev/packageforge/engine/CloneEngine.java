package dev.packageforge.engine;

import com.reandroid.apk.ApkBundle;
import com.reandroid.apk.ApkModule;
import com.reandroid.archive.FileInputSource;
import com.reandroid.archive.InputSource;
import com.reandroid.arsc.chunk.xml.AndroidManifestBlock;
import com.reandroid.arsc.chunk.xml.ResXmlAttribute;
import com.reandroid.arsc.chunk.xml.ResXmlElement;
import com.reandroid.arsc.value.DataType;
import com.reandroid.dex.id.StringId;
import com.reandroid.dex.model.DexFile;
import com.reandroid.dex.model.DexLayout;
import com.reandroid.dex.sections.Section;
import com.reandroid.dex.sections.SectionType;
import java.io.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.*;

/** Android-independent pipeline, also exercised against real APK fixtures on the JVM. */
public final class CloneEngine {
    public interface Progress { void update(int percent, String message) throws IOException; }
    public static final long MAX_BYTES = 4L * 1024 * 1024 * 1024;
    public static final int MAX_APKS = 512;
    private static final Pattern PACKAGE = Pattern.compile("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+");
    private static final Set<String> COMPONENTS = new HashSet<>(Arrays.asList("application", "activity", "activity-alias", "service", "receiver", "provider", "instrumentation"));
    private static final String ANDROID = "http://schemas.android.com/apk/res/android";

    public static boolean validPackage(String value) {
        return value != null && value.length() <= 200 && PACKAGE.matcher(value).matches() && !value.startsWith("android.") && !value.equals("android");
    }
    public static void checkCancelled() throws InterruptedIOException {
        if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException("Cancelled");
    }
    public static void copy(InputStream input, OutputStream output, long limit) throws IOException {
        byte[] buffer = new byte[65536]; long count = 0; int read;
        while ((read = input.read(buffer)) != -1) {
            checkCancelled(); count += read;
            if (count > limit) throw new IOException("Input exceeds the 4 GiB safety limit.");
            output.write(buffer, 0, read);
        }
    }

    /** Accept a real APK, or a single variant APKM/XAPK/APKS ZIP. Paths never come from ZIP names. */
    public static List<File> unpack(File input, File destination, Progress progress) throws IOException {
        if (!destination.isDirectory() && !destination.mkdirs()) throw new IOException("Cannot create workspace.");
        try (ZipFile zip = new ZipFile(input)) {
            if (zip.getEntry("AndroidManifest.xml") != null) return Collections.singletonList(input);
            List<? extends ZipEntry> entries = Collections.list(zip.entries());
            List<File> apks = new ArrayList<>(); long total = 0;
            // Prefer bundletool's universal APK when supplied alongside device variants.
            ZipEntry universal = null;
            for (ZipEntry entry : entries) if (entry.getName().equals("universal.apk")) universal = entry;
            if (universal != null) entries = Collections.singletonList(universal);
            for (ZipEntry entry : entries) {
                checkCancelled();
                String name = entry.getName().toLowerCase(Locale.ROOT);
                if (name.endsWith(".obb")) throw new IOException("This archive includes OBB expansion data. Export an APK-only split set; OBB relocation is not supported.");
                if (entry.isDirectory() || !name.endsWith(".apk")) continue;
                if (apks.size() >= MAX_APKS) throw new IOException("Too many APKs in the archive.");
                File target = new File(destination, "part-" + apks.size() + ".apk");
                try (InputStream in = zip.getInputStream(entry); OutputStream out = new FileOutputStream(target)) { copy(in, out, MAX_BYTES - total); }
                total += target.length(); apks.add(target);
                progress.update(12, "Reading split " + apks.size());
            }
            if (apks.isEmpty()) throw new IOException("No APKs found. Choose an APK, APKM, XAPK or APKS file. AAB source bundles are not supported.");
            return apks;
        } catch (ZipException e) { throw new IOException("The selected file is not a readable APK or ZIP bundle.", e); }
    }

    public static String build(List<File> inputs, File output, File scratch, String target, String label, boolean patchStrings, Progress progress) throws IOException {
        if (!validPackage(target)) throw new IOException("Enter a valid package name, such as com.example.emulator.");
        if (inputs.isEmpty()) throw new IOException("Select an app first.");
        scratch.mkdirs();
        try (ApkBundle bundle = new ApkBundle()) {
            String original = null; Integer version = null; int bases = 0; Set<String> splits = new HashSet<>();
            for (int i = 0; i < inputs.size(); i++) {
                checkCancelled(); progress.update(18, "Loading APK " + (i + 1) + " of " + inputs.size());
                ApkModule module = ApkModule.loadApkFile(inputs.get(i), "part-" + i);
                bundle.addModule(module);
                if (!module.hasAndroidManifest()) throw new IOException("An input APK has no Android manifest.");
                AndroidManifestBlock manifest = module.getAndroidManifest();
                String pkg = manifest.getPackageName();
                if (pkg == null) throw new IOException("An input has an invalid manifest package.");
                if (original == null) { original = pkg; version = manifest.getVersionCode(); }
                if (!original.equals(pkg) || !Objects.equals(version, manifest.getVersionCode())) throw new IOException("These splits belong to different apps or versions.");
                ResXmlAttribute split = manifest.getManifestElement().searchAttributeByName("split");
                String splitName = split == null ? null : split.getDataAsString();
                if (splitName == null || splitName.isEmpty()) bases++;
                else if (!splits.add(splitName)) throw new IOException("The archive contains multiple device variants of the same split. Export the app from this device or provide one device-specific split set.");
            }
            if (bases != 1) throw new IOException("Expected exactly one base APK. This may be a multi-device APKS archive; supply a universal APK or one device-specific split set.");
            if (target.equals(original)) throw new IOException("Choose a package name different from the original.");
            progress.update(30, inputs.size() > 1 ? "Merging " + inputs.size() + " split APKs" : "Preparing APK");
            try (ApkModule merged = bundle.mergeModules()) {
                checkCancelled(); progress.update(48, "Updating package and component identities");
                Map<String, String> identities = rewriteManifest(merged.getAndroidManifest(), original, target, label);
                merged.setPackageName(target);
                // Extraction avoids native-library alignment restrictions in rewritten APKs.
                merged.getAndroidManifest().setExtractNativeLibs(true);
                merged.setExtractNativeLibs(true);
                merged.setApkSignatureBlock(null);
                for (InputSource source : merged.getZipEntryMap().toArray()) {
                    String name = source.getAlias();
                    if (name.toUpperCase(Locale.ROOT).startsWith("META-INF/") && (name.toUpperCase(Locale.ROOT).matches(".*\\.(SF|RSA|DSA|EC)$") || name.equalsIgnoreCase("META-INF/MANIFEST.MF"))) merged.getZipEntryMap().remove(source);
                    if (name.equals("stamp-cert-sha256")) merged.getZipEntryMap().remove(source);
                }
                if (patchStrings) patchDex(merged, scratch, original, target, identities, progress);
                checkCancelled(); progress.update(72, "Writing standalone APK");
                merged.refreshManifest(); merged.refreshTable(); merged.writeApk(output);
            }
            return original;
        }
    }

    static Map<String, String> rewriteManifest(AndroidManifestBlock manifest, String original, String target, String label) throws IOException {
        Map<String, String> replacements = new LinkedHashMap<>(); replacements.put(original, target);
        List<ResXmlElement> elements = new ArrayList<>(); manifest.recursiveElements().forEachRemaining(elements::add);
        int authorityIndex = 0;
        for (ResXmlElement element : elements) {
            String tag = element.getName();
            if ("provider".equals(tag)) {
                ResXmlAttribute attr = element.searchAttributeByName("authorities");
                if (attr != null) {
                    if (attr.getDataType() != DataType.STRING) throw new IOException("Resource-based provider authorities are not supported by this version.");
                    for (String authority : attr.getDataAsString().split(";")) {
                        if (!authority.isEmpty()) replacements.put(authority, authority.startsWith(original + ".") ? target + authority.substring(original.length()) : target + ".provider" + (++authorityIndex));
                    }
                }
            }
            if (tag.equals("permission") || tag.equals("permission-group") || tag.equals("permission-tree")) {
                ResXmlAttribute attr = element.searchAttributeByName("name");
                if (attr != null && attr.getDataType() == DataType.STRING) {
                    String value = attr.getDataAsString();
                    replacements.put(value, value.startsWith(original + ".") ? target + value.substring(original.length()) : target + ".permission." + value);
                }
            }
            if (tag.equals("action") || tag.equals("category")) {
                ResXmlAttribute attr = element.searchAttributeByName("name");
                if (attr != null && attr.getDataType() == DataType.STRING) {
                    String value = attr.getDataAsString();
                    if (value.startsWith(original + ".")) replacements.put(value, target + value.substring(original.length()));
                }
            }
        }
        for (ResXmlElement element : elements) {
            for (Iterator<ResXmlAttribute> it = element.getAttributes(); it.hasNext();) {
                ResXmlAttribute attr = it.next(); String key = attr.getName();
                if (element == manifest.getManifestElement() && (key.equals("sharedUserId") || key.equals("sharedUserLabel") || key.equals("sharedUserMaxSdkVersion"))) { element.removeAttribute(attr); continue; }
                if (attr.getDataType() != DataType.STRING) continue;
                String value = attr.getDataAsString(); String tag = element.getName();
                boolean className = (key.equals("name") && COMPONENTS.contains(tag) && !tag.equals("activity-alias")) || Arrays.asList("targetActivity", "parentActivityName", "backupAgent", "manageSpaceActivity", "appComponentFactory", "zygotePreloadName").contains(key);
                if (className && ANDROID.equals(attr.getUri())) {
                    if (value.startsWith(".")) attr.setDataAsString(original + value);
                    else if (!value.contains(".")) attr.setDataAsString(original + "." + value);
                    continue;
                }
                if (key.equals("authorities")) {
                    String[] values = value.split(";");
                    for (int i = 0; i < values.length; i++) values[i] = replacements.getOrDefault(values[i], values[i]);
                    attr.setDataAsString(String.join(";", values));
                } else if (key.equals("taskAffinity") || key.equals("process")) {
                    if (value.equals(original) || value.startsWith(original + ".")) attr.setDataAsString(target + value.substring(original.length()));
                } else if (replacements.containsKey(value) && !key.equals("package") && !key.equals("value") && !key.equals("scheme") && !key.equals("host")) {
                    attr.setDataAsString(replacements.get(value));
                }
            }
            // Launcher-specific labels otherwise override the application label.
            if (label != null && !label.trim().isEmpty() && (element.getName().equals("activity") || element.getName().equals("activity-alias"))) {
                ResXmlAttribute attr = element.searchAttributeByName("label");
                if (attr != null) attr.setDataAsString(label.trim());
            }
        }
        if (label != null && !label.trim().isEmpty()) manifest.setApplicationLabel(label.trim());
        return replacements;
    }

    private static void patchDex(ApkModule module, File scratch, String original, String target, Map<String,String> identities, Progress progress) throws IOException {
        int number = 0;
        for (InputSource source : module.getZipEntryMap().toArray()) {
            if (!source.getAlias().matches("classes(\\d+)?\\.dex")) continue;
            checkCancelled(); progress.update(58, "Patching package literals in " + source.getAlias());
            try (InputStream in = source.openStream(); DexFile dex = DexFile.read(in)) {
                int changed = 0;
                for (DexLayout layout : dex) {
                    Section<StringId> section = layout.getSection(SectionType.STRING_ID);
                    if (section == null) continue;
                    Iterator<StringId> strings = section.clonedIterator();
                    while (strings.hasNext()) {
                        StringId id = strings.next(); String value = id.getString();
                        String updated = identities.get(value);
                        if (updated == null && value != null && value.startsWith("content://")) {
                            int slash = value.indexOf('/', 10); String authority = slash < 0 ? value.substring(10) : value.substring(10, slash);
                            if (identities.containsKey(authority)) updated = "content://" + identities.get(authority) + (slash < 0 ? "" : value.substring(slash));
                        }
                        if (updated != null && !updated.equals(value)) { id.setString(updated); changed++; }
                    }
                }
                if (changed > 0) {
                    dex.refreshFull();
                    File rewritten = new File(scratch, "patched-" + (++number) + ".dex"); dex.write(rewritten);
                    module.add(new FileInputSource(rewritten, source.getAlias()));
                }
            }
        }
    }
}
