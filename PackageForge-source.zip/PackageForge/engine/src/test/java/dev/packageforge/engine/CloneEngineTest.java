package dev.packageforge.engine;

import com.reandroid.apk.ApkModule;
import com.reandroid.archive.ByteInputSource;
import com.reandroid.arsc.chunk.xml.*;
import com.reandroid.dex.model.*;
import com.reandroid.dex.id.StringId;
import com.reandroid.dex.sections.SectionType;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class CloneEngineTest {
    @Rule public TemporaryFolder temp = new TemporaryFolder();
    private File fixture() { return new File(System.getProperty("fixtureApk")); }
    private File cloneApk(boolean patch) throws Exception {
        File output = new File(temp.getRoot(), "clone-" + patch + ".apk");
        CloneEngine.build(Collections.singletonList(fixture()),output,temp.newFolder(),"com.antutu.ABenchMark","My Emulator",patch,(p,m)->{}); return output;
    }
    private Set<String> strings(ApkModule module) throws Exception {
        Set<String> values=new HashSet<>();
        for(com.reandroid.archive.InputSource source:module.getZipEntryMap().toArray()) {
            if(!source.getAlias().matches("classes(\\d+)?\\.dex"))continue;
            try(InputStream in=source.openStream(); DexFile dex=DexFile.read(in)) {
                for(DexLayout l:dex) { Iterator<StringId> it=l.getDexLayoutBlock().getStrings(); while(it.hasNext())values.add(it.next().getString()); }
            }
        } return values;
    }
    @Test public void compiledApkKeepsClassesResourcesAndRewritesIdentities() throws Exception {
        try(ApkModule apk=ApkModule.loadApkFile(cloneApk(true))) {
            AndroidManifestBlock m=apk.getAndroidManifest();
            assertEquals("com.antutu.ABenchMark",m.getPackageName());
            assertEquals("My Emulator",m.getApplicationLabelString());
            ResXmlElement application=m.getApplicationElement();
            assertEquals("com.antutu.ABenchMark",application.searchAttributeByName("taskAffinity").getDataAsString());
            assertEquals("dev.packageforge.fixture.ProbeActivity",application.getElement("activity").searchAttributeByName("name").getDataAsString());
            assertEquals("com.antutu.ABenchMark.files;com.antutu.ABenchMark.provider1",application.getElement("provider").searchAttributeByName("authorities").getDataAsString());
            assertEquals("com.antutu.ABenchMark.INTERNAL",m.getManifestElement().getElement("permission").searchAttributeByName("name").getDataAsString());
            assertEquals("com.antutu.ABenchMark",apk.getTableBlock().get(0).getName());
            assertEquals("Resources survived",apk.getTableBlock().get(0).getEntry("", "string", "resource_probe").getDataAsString());
            assertEquals("Ressources intactes",apk.getTableBlock().get(0).getEntry("-fr", "string", "resource_probe").getDataAsString());
            Set<String> strings=strings(apk);
            assertTrue(strings.toString(),strings.contains("com.antutu.ABenchMark"));
            assertTrue(strings.contains("content://com.antutu.ABenchMark.files/probe"));
            assertTrue(strings.contains("Ldev/packageforge/fixture/ProbeActivity;"));
            assertFalse(strings.contains("dev.packageforge.fixture"));
            assertNull(apk.getZipEntryMap().getInputSource("META-INF/CERT.SF"));
        }
    }
    @Test public void canLeaveDexUnmodified() throws Exception {
        try(ApkModule original=ApkModule.loadApkFile(fixture());ApkModule cloned=ApkModule.loadApkFile(cloneApk(false))) {
            for(com.reandroid.archive.InputSource a:original.getZipEntryMap().toArray()) {
                if(!a.getAlias().matches("classes(\\d+)?\\.dex"))continue;
                com.reandroid.archive.InputSource b=cloned.getZipEntryMap().getInputSource(a.getAlias());
                assertArrayEquals(a.getBytes((int)a.getLength()),b.getBytes((int)b.getLength()));
            }
        }
    }
    @Test public void mergesSplitDexAssetsAndSanitizesSplitMetadata() throws Exception {
        File split=new File(temp.getRoot(),"split.apk");
        try(ApkModule s=new ApkModule()) {
            AndroidManifestBlock m=new AndroidManifestBlock();m.setPackageName("dev.packageforge.fixture");m.setVersionCode(1);
            m.getManifestElement().getOrCreateAttribute("split",0).setDataAsString("feature_probe");
            m.getManifestElement().getOrCreateAndroidAttribute("isFeatureSplit",0x0101055b).setValueAsBoolean(true);
            m.getOrCreateApplicationElement();s.setManifest(m);
            try(DexFile extra=DexFile.createDefault()) {
                extra.getOrCreateFirst().getOrCreateClass(com.reandroid.dex.key.TypeKey.create("Ldev/packageforge/feature/Extra;"))
                    .setSuperClass(com.reandroid.dex.key.TypeKey.create("Ljava/lang/Object;"));
                extra.refreshFull(); ByteArrayOutputStream bytes=new ByteArrayOutputStream(); extra.write(bytes);
                s.add(new ByteInputSource(bytes.toByteArray(),"classes.dex"));
            }
            try(ApkModule base=ApkModule.loadApkFile(fixture())) {
                com.reandroid.arsc.chunk.TableBlock table=new com.reandroid.arsc.chunk.TableBlock();
                table.merge(base.getTableBlock());
                table.get(0).getOrCreate("-es", "string", "resource_probe").setDataAsString("Recursos intactos");
                s.setTableBlock(table);
            }
            s.add(new ByteInputSource("split resource payload".getBytes("UTF-8"),"assets/feature.txt")); s.writeApk(split);
        }
        File output=new File(temp.getRoot(),"merged.apk");
        CloneEngine.build(Arrays.asList(fixture(),split),output,temp.newFolder(),"com.example.merged","Merged",false,(p,m)->{});
        try(ApkModule merged=ApkModule.loadApkFile(output)) {
            assertNotNull(merged.getZipEntryMap().getInputSource("assets/feature.txt"));
            assertNull(merged.getAndroidManifest().getManifestElement().searchAttributeByName("split"));
            assertEquals("com.example.merged",merged.getPackageName());
            assertEquals("Recursos intactos",merged.getTableBlock().get(0).getEntry("-es", "string", "resource_probe").getDataAsString());
            assertTrue(strings(merged).contains("Ldev/packageforge/feature/Extra;"));
            assertTrue(strings(merged).contains("Ldev/packageforge/fixture/ProbeActivity;"));
        }
    }
    @Test public void rejectsMismatchedOrMissingBaseAndSamePackage() throws Exception {
        for(String target:Arrays.asList("dev.packageforge.fixture","bad-package")) {
            try { CloneEngine.build(Collections.singletonList(fixture()),temp.newFile(),temp.newFolder(),target,"",false,(p,m)->{}); fail(); }
            catch(IOException expected) { assertFalse(expected.getMessage().isEmpty()); }
        }
        try { CloneEngine.build(Arrays.asList(fixture(),fixture()),temp.newFile(),temp.newFolder(),"com.example.clone","",false,(p,m)->{}); fail(); }
        catch(IOException expected) { assertTrue(expected.getMessage().contains("base")); }
    }
    @Test public void archiveCannotEscapeWorkspaceAndHonorsLimits() throws Exception {
        File zip=temp.newFile("traversal.apkm");
        try(ZipOutputStream out=new ZipOutputStream(new FileOutputStream(zip))) {
            out.putNextEntry(new ZipEntry("../../escape.apk")); Files.copy(fixture().toPath(),out);out.closeEntry();
        }
        File workspace=temp.newFolder();List<File> files=CloneEngine.unpack(zip,workspace,(p,m)->{});
        assertEquals(1,files.size());assertEquals(workspace.getCanonicalFile(),files.get(0).getParentFile().getCanonicalFile());
        try { CloneEngine.copy(new ByteArrayInputStream(new byte[20]),new ByteArrayOutputStream(),10);fail(); }catch(IOException expected){}
    }
    @Test public void rejectsObbAndNonApkArchives() throws Exception {
        for(String entry:Arrays.asList("main.obb","BundleConfig.pb")) {
            File zip=temp.newFile();try(ZipOutputStream out=new ZipOutputStream(new FileOutputStream(zip))){out.putNextEntry(new ZipEntry(entry));out.write(1);out.closeEntry();}
            try{CloneEngine.unpack(zip,temp.newFolder(),(p,m)->{});fail();}catch(IOException expected){assertTrue(expected.getMessage().contains(entry.endsWith("obb")?"OBB":"No APKs"));}
        }
    }
    @Test public void packageValidationAndCancellation() throws Exception {
        assertTrue(CloneEngine.validPackage("com.antutu.ABenchMark"));assertTrue(CloneEngine.validPackage("com.example.app_2"));
        for(String value:Arrays.asList("android.fake","single","com..app",".bad","com.2bad","com.a/b",""))assertFalse(value,CloneEngine.validPackage(value));
        Thread.currentThread().interrupt();try{CloneEngine.checkCancelled();fail();}catch(InterruptedIOException expected){}finally{Thread.interrupted();}
    }
    @Test public void relativeClassesAreQualifiedBeforeChangingApplicationId() throws Exception {
        AndroidManifestBlock m=new AndroidManifestBlock();m.setPackageName("com.original.emulator");
        ResXmlElement root=m.getManifestElement(), app=m.getOrCreateApplicationElement();
        root.getOrCreateAndroidAttribute("sharedUserId",0x0101000b).setDataAsString("com.original.emulator.shared");
        app.getOrCreateAndroidAttribute("name",0x01010003).setDataAsString(".App");
        app.getOrCreateAndroidAttribute("backupAgent",0x0101027f).setDataAsString("Backup");
        ResXmlElement activity=app.newElement("activity");
        activity.getOrCreateAndroidAttribute("name",0x01010003).setDataAsString("MainActivity");
        activity.getOrCreateAndroidAttribute("parentActivityName",0x010103a7).setDataAsString(".Parent");
        CloneEngine.rewriteManifest(m,"com.original.emulator","com.newname.emulator","");
        assertEquals("com.original.emulator.App",app.searchAttributeByName("name").getDataAsString());
        assertEquals("com.original.emulator.Backup",app.searchAttributeByName("backupAgent").getDataAsString());
        assertEquals("com.original.emulator.MainActivity",activity.searchAttributeByName("name").getDataAsString());
        assertEquals("com.original.emulator.Parent",activity.searchAttributeByName("parentActivityName").getDataAsString());
        assertNull(root.searchAttributeByName("sharedUserId"));
    }
}
