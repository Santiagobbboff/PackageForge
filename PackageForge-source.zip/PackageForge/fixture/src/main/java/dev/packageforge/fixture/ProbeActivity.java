package dev.packageforge.fixture;
public class ProbeActivity extends android.app.Activity {
    @Override public void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        android.widget.TextView t = new android.widget.TextView(this);
        String literal = "dev.packageforge.fixture";
        String authority = "dev.packageforge.fixture.files";
        String uri = "content://dev.packageforge.fixture.files/probe";
        boolean pkgOk = getPackageName().equals(literal);
        android.database.Cursor c = getContentResolver().query(android.net.Uri.parse(uri),null,null,null,null);
        boolean providerOk = c != null; if (c != null) c.close();
        t.setText("PACKAGE="+getPackageName()+"\nLITERAL="+literal+"\nAUTHORITY="+authority+"\nPKG_OK="+pkgOk+"\nPROVIDER_OK="+providerOk+"\n"+getString(R.string.resource_probe));
        t.setTextSize(20); t.setPadding(24,64,24,24); setContentView(t);
        android.util.Log.i("ForgeFixture",t.getText().toString());
    }
}
