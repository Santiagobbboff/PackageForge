package dev.packageforge.fixture;
public class ProbeProvider extends android.content.ContentProvider {
    public boolean onCreate(){return true;}
    public android.database.Cursor query(android.net.Uri u,String[] p,String s,String[] a,String o){android.database.MatrixCursor c=new android.database.MatrixCursor(new String[]{"ok"});c.addRow(new Object[]{1});return c;}
    public String getType(android.net.Uri u){return "text/plain";}
    public android.net.Uri insert(android.net.Uri u,android.content.ContentValues v){return null;}
    public int update(android.net.Uri u,android.content.ContentValues v,String s,String[] a){return 0;}
    public int delete(android.net.Uri u,String s,String[] a){return 0;}
}
